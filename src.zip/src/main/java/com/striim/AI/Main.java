package com.striim.AI;


import java.util.List;

public class Main {
    public static void main(String[] args) {
//
////
////        ModelResponse<Embedding> embeddingResponse = new OpenAIEmbeddingService().getEmbedding(OpenAiEmbeddingOptions.builder()
////                .withModel("text-embedding-ada-002")
////                .withUser("user-6")
////                .build());
//        RSocketRequester rsocketRequester = RSocketRequester.builder()
//                .rsocketConnector(RSocketConnector.connectWith(TcpClientTransport.create("localhost", 7000)))
//                .dataMimeType(MimeTypeUtils.APPLICATION_JSON)
//                .build();
//
//        org.springframework.ai.openai.OpenAiEmbeddingOptions build = OpenAiEmbeddingOptions.builder()
//                .withModel("text-embedding-ada-002")
//                .withUser("user-6")
//                .build();
//
//        OpenAiEmbeddingOptions request = new OpenAiEmbeddingOptions();
//        request.setContent(Arrays.as"Hello");
//
//        rsocketRequester.route("generate.embedding")
//                .data(re)
//                .retrieveFlux(new ParameterizedTypeReference<List<Double>>() {
//                });


    }


}
