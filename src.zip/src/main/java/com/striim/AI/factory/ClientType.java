package com.striim.AI.factory;

public enum ClientType {
    AZURE_OPENAI,
    OLLAMA,
    OPENAI,
    VERTEXAI, // Assuming you will implement this later
    POSTGRESML,
    AMAZON_BED_ROCK
}
